$('#submit').submit(
    function (){
            var retval = true
            var email = $("#email").val();
            var EmailError = $("#EmailError")

            if ($("#email").val().trim().length <3){
                retval = false
                console.log(retval)
                $("#EmailError").toggleClass("d-block");
            }



            if (retval == true){
                console.log("Submit Done")
                alert("Email registado com sucesso!")
            }
    },
    console.log("Ready!"))

