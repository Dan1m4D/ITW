var drivervm = function(){
    console.log('Driver Model iniciated ...')
    //---Variáveis locais
    var self = this;
    self.baseUri = ko.observable('http://192.168.160.58/Formula1/api/Drivers/Driver?id=');
    self.displayName = 'Driver Details';
    self.error = ko.observable('');
    self.passingMessage = ko.observable('');
    //--- Data Record
    self.DriverId = ko.observable('');
    self.DriverRef = ko.observable('');
    self.ImageUrl = ko.observable('');
    self.Name = ko.observable('');
    self.Nationality = ko.observable('');
    self.Number = ko.observable('');
    self.Races = ko.observableArray('');
    self.Url = ko.observable('');

    //--- Page Events
    self.activate = function (id) {
        console.log('CALL: getDriver...');
        var composedUri = self.baseUri() + id;
        ajaxHelper(composedUri, 'GET').done(function (data) {
            console.log(data);
            self.DriverId(data.DriverId);
            self.DriverRef(data.DriverRef);
            self.ImageUrl(data.ImageUrl);
            self.Name(data.Name);
            self.Nationality(data.Nationality);
            self.Number(data.Number);
            self.Races(data.Races);
            self.Url(data.Url);
            hideLoading();
        });
    };
    //--- Internal functions
    function ajaxHelper(uri, method, data) {
        self.error(''); // Clear error message
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null,
            error: function (jqXHR, textStatus, errorThrown) {
                console.log("AJAX Call[" + uri + "] Fail...");
                hideLoading();
                self.error(errorThrown);
            }
        });

};
//--- Internal functions
function ajaxHelper(uri, method, data) {
    self.error(''); // Clear error message
    return $.ajax({
        type: method,
        url: uri,
        dataType: 'json',
        contentType: 'application/json',
        data: data ? JSON.stringify(data) : null,
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("AJAX Call[" + uri + "] Fail...");
            hideLoading();
            self.error(errorThrown);
        }
    });
}







$("document").ready(
    function validate(){
        var retval = true
        var email = $("#email").val();
        var pass = $("#pass").val();
        var PassError = $("#PassError");
        var EmailError = $("#EmailError")

        if (email != 'test1234@ua.pt && pass != test1234'){
            retval = false
            $("#EmailError").toggleClass('d-none d-block');
            $('input.login').val('');
            $('#PassError"').toggleClass('d-none d-block');
            $('input.login').val('');
        }
        else if (email != "test1234@ua.pt"){
            retval = false
            EmailError.toggleClass('d-none d-block');
            $('input.login').val('');
        }
        else if (pass != 'test1234'){
            retval = false
            PassError.toggleClass('d-none d-block');
            $('input.login').val('');
        }
        if (retval == true){
            console.log("Login válido")}
        else {}
        return retval
    })

    console.log("ready!");
    ko.applyBindings(new drivervm());

}
