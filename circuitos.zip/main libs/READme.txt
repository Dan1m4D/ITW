Libraries for work with web development : 

* jquery-3.6.0 : for D.O.M 
* jquery-ui-1.13.0 : for user interface desing
* font awesome 5.15.4 : for icons
* bootstrap-5.1.3 : for a responsive web desing
* knockout-min : to write less javascript code in your .js file 
*Any other that you would want to use ...

Just import these files on your html file, with the <link/> tag for css files or <script src=""></script> for javascript files