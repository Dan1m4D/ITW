var drivervm = function(){
    console.log('Driver Model iniciated ...')

    var self = this;

    self.DriverBaseURL = ko.obervable('http://192.168.160.58/Formula1/api/Drivers/Drivers')
    self.error = ko.observable('');
    self.passingMessage = ko.observable('');
    self.records = ko.observableArray([]);
    self.displayName = 'Driver Details';
    self.error = ko.observable('');
    self.passingMessage = ko.observable('');
    //--- Data Record
    self.DriverId = ko.observable('');
    self.ImageUrl = ko.observable('');
    self.Name = ko.observable('');
    self.Nationality = ko.observable('');
    self.Url = ko.observable('');

    //--- Page Events
    self.activate = function (id) {
        console.log('CALL: getDriver...');
        var DriverUri = self.baseUri() + id;
        ajaxHelper(DriverUri, 'GET').done(function (data) {
            console.log(data);
            self.DriverId(data.DriverId);
            self.ImageUrl(data.ImageUrl);
            self.Name(data.Name);
            self.Nationality(data.Nationality);
            hideLoading();
        });
    };
    //--- Internal functions
    function ajaxHelper(uri, method, data) {
        self.error(''); // Clear error message
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null,
            error: function (jqXHR, textStatus, errorThrown) {
                console.log("AJAX Call[" + uri + "] Fail...");
                hideLoading();
                self.error(errorThrown);
            }
        });
    }







$("document").ready(
    function validate(){
        var retval = true
        var email = $("#email").val();
        var pass = $("#pass").val();
        var PassError = $("#PassError");
        var EmailError = $("#EmailError")

        if (email != 'test1234@ua.pt && pass != test1234'){
            retval = false
            $("#EmailError").toggleClass('d-none d-block');
            $('input.login').val('');
            $('#PassError"').toggleClass('d-none d-block');
            $('input.login').val('');
        }
        else if (email != "test1234@ua.pt"){
            retval = false
            EmailError.toggleClass('d-none d-block');
            $('input.login').val('');
        }
        else if (pass != 'test1234'){
            retval = false
            PassError.toggleClass('d-none d-block');
            $('input.login').val('');
        }
        if (retval == true){
            console.log("Login válido")}
        else {}
        return retval
    })

}
