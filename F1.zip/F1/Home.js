$("document").ready(
    function(){
        var button = document.getElementById("LoginBtn")
        button.click(function(){
            return null
        })
    }
)