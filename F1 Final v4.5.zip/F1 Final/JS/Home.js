$(document).ready(
$('#submit').click(
    function (){
            var retval = true

            if (retval == true){
                console.log("Submit Done")
                alert("Email registado com sucesso!")
            }
    },
    console.log("Ready!"))
)
